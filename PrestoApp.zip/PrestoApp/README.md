# PrestoAppsAngularTest
PrestoApps Angular Test
 npm install
 ng serve