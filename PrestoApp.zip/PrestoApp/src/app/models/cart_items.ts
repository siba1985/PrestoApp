export interface CartItem {
  product_id: number;
  product_name: string;
  img: string;
  qty: string;
  price: number;
  total_price: number;
}
