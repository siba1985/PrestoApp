export interface Product {
  id: number;
  name: string;
  img: string;
  desc: string;
  weight: string;
  price: number;
  long_desc: string;
}
